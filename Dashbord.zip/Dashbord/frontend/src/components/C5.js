import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Container, Form, Nav, Navbar, Card } from 'react-bootstrap'
import { RiSchoolFill } from "react-icons/ri";
import { IoMdTime } from "react-icons/io";
import { IoIosSchool } from "react-icons/io";
import axios from 'axios';
import { useEffect, useState } from 'react';
import { BarChart, PieChart, pieArcLabelClasses, LineChart, SparkLineChart } from '@mui/x-charts';

function C5() {
  const [influential, setInfluential] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [menBetterSTEM, setMenBetterSTEM] = useState([]);
  const [school_activity_club, setSchool_activity_club] = useState([]);
  const [feedback, setFeedback] = useState([]);
  const [perc_academic, setPerc_Academic] = useState([]);
  const [comfortable, setcomfortable] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/admins/dashboard')
      .then(function (response) {
        setInfluential(response.data.influential);
        setAttendance(response.data.attendance);
        setMenBetterSTEM(response.data.menBetterSTEM);
        setSchool_activity_club(response.data.school_activity_club);
        setFeedback(response.data.feedback);
        setPerc_Academic(response.data.perc_academic);
        setcomfortable(response.data.comfortable);
        console.log(response.data.COVID.filter(item => item._id !== 'NA').map(item => item._id));
        console.log()
      })
      .catch(function (error) {
        console.log(error);
      })
  }, []);

  return (
    <div>
      
      <div className='body1'>

        <div className='container' >
          <section className=' w-100 row gap-5  '>
           
            <div className='d-flex w-100 gap-5'>
            <div >
                {perc_academic.length > 0 && (
                  <div className='bg-white d-inline-block rounded m-auto1'>
                    <h3>Count of students by Perc Academic</h3>
                    <LineChart
                      xAxis={[{ data: perc_academic.filter(item => item._id !== 'NA').map(item => item._id), }]}
                      series={[
                        {
                          data: perc_academic.filter(item => item._id !== 'NA').map(item => item.count),
                          area: true,
                        },
                      ]}
                      width={700}
                      height={500}
                    />
                  </div>
                )}
                {/* <p className='text-center '>fig.5:Count of students by Perc Academic</p>  */}
              </div>
            </div>
            
          </section>
        </div>
      </div>
    </div>
  );
}

export default  C5;
