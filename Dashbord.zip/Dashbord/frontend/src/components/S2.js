
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Container, Form, Nav, Navbar, Card } from 'react-bootstrap'
import { RiSchoolFill } from "react-icons/ri";
import { IoMdTime } from "react-icons/io";
import { IoIosSchool } from "react-icons/io";

import axios from 'axios';
import { useEffect, useState } from 'react';
import { BarChart, PieChart, pieArcLabelClasses, LineChart, SparkLineChart } from '@mui/x-charts';

function S2() {
  const [completeYears, setCompleteYears] = useState([]);
  const [isolated, setisolated] = useState([]);
  const [opinion, setOpinion] = useState([]);
  const [school_activity_club, setSchool_activity_club] = useState([]);
  const [COVID, setCOVID] = useState([]);
  const [bullying, setBullying] = useState([]);
  const [comfortable, setcomfortable] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/admins/dashboard')
      .then(function (response) {
        setCompleteYears(response.data.completeYears);
        setisolated(response.data.isolated);
        setOpinion(response.data.opinion);
        setSchool_activity_club(response.data.school_activity_club);
        setCOVID(response.data.COVID);
        setBullying(response.data.bullying);
        setcomfortable(response.data.comfortable);
        console.log(response.data.COVID.filter(item => item._id !== 'NA').map(item => item._id));
        console.log()
      })
      .catch(function (error) {
        console.log(error);
      })
  }, []);

  return (
    <div>
      
      <div className='body1'>

        <div className='container' >
          <section className=' w-100 row gap-5  '>
           <div className='d-flex w-100 gap-5'>
           <div>
            {isolated.length > 0 && (
                <div className='bg-white d-inline-block rounded m-auto1'>
                  <h3>Count of students by Isolated</h3>
                  <PieChart
                    series={[
                      {
                        innerRadius: 80,
                        outerRadius: 120,
                        data: isolated.map(item => ({ label: String(item._id), value: item.count })),
                      },
                    ]}
                    width={800}
                    height={450}
                  />
                </div>
              )}
               
           </div>
           
            </div>
           
          </section>
        </div>
      </div>
    </div>
  );
}

export default S2;
