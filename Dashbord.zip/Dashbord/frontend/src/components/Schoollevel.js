
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Container, Form, Nav, Navbar, Card } from 'react-bootstrap'
import { FaFacebook, FaInstagram, FaTwitter } from "react-icons/fa";
import axios from 'axios';
import { useEffect, useState } from 'react';
import { BarChart, PieChart, LineChart } from '@mui/x-charts';
import Logout from './Logout';

function Schoollevel() {
  const [completeYears, setCompleteYears] = useState([]);
  const [isolated, setisolated] = useState([]);
  const [opinion, setOpinion] = useState([]);
  const [school_activity_club, setSchool_activity_club] = useState([]);
  const [COVID, setCOVID] = useState([]);
  const [bullying, setBullying] = useState([]);
  const [comfortable, setcomfortable] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/admins/dashboard')
      .then(function (response) {
        setCompleteYears(response.data.completeYears);
        setisolated(response.data.isolated);
        setOpinion(response.data.opinion);
        setSchool_activity_club(response.data.school_activity_club);
        setCOVID(response.data.COVID);
        setBullying(response.data.bullying);
        setcomfortable(response.data.comfortable);
        console.log(response.data.COVID.filter(item => item._id !== 'NA').map(item => item._id));
        console.log()
      })
      .catch(function (error) {
        console.log(error);
      })
  }, []);

  return (
    <div>
      <div className='header-bg-green'>
        <header className='header1 container'>
          <Navbar expand="lg" className="">
            <Container fluid>
              <Navbar.Brand href="/" className='text-white'>ANALYTICS</Navbar.Brand>
              <Navbar.Toggle aria-controls="navbarScroll" />
              <Navbar.Collapse id="navbarScroll">
                <Nav className="me-auto my-2 my-lg-0" style={{ maxHeight: '100px' }} navbarScroll></Nav>
                <Form className="d-flex">
                  <Button className='m-2 text-white border-white' variant="outline-success"><Logout /></Button>
                </Form>
              </Navbar.Collapse>
            </Container>
          </Navbar>
        </header>
      </div>
      <div className='body'>
        <section>
          <div className="container1">
            <section className="carousel slide" id="carousel" data-bs-ride="carousel">
              <div className="carousel-inner">
                <div className="carousel-item active" data-bs-interval="">
                  <div className="container h-75">
                    <div className="d-flex justify-content-start align-items-center h-100">
                      <div className="text-start text-white">
                        <h2 className="fw-bold  display-2">School Level</h2>
                        <h5 className="p-2 my-3 fs-7 d-flex flex-wrap opacity-75">"Data-Driven Insights for Educational Excellence – Our interactive dashboard transforms complex survey<br></br> data into clear visual narratives, providing educators, administrators, and policymakers with actionable<br></br> insights into school culture, student academic performance, and psychological well-being.Revolutionizing<br></br> School Performance with Smart Analytics – Harness the power of real-time data analysis with our advanced<br></br> analytics platform. Tailored specifically for the education sector, this tool offers dynamic visualizations that<br></br> turn raw data into valuable insights, empowering school leaders, teachers, and stakeholders to make<br></br> informed decisions that foster student success and institutional growth."</h5><br />
                        <div className='d-flex'>
                        <input type="button" name defaultValue="Class Level" className='mb-3 text-white border-white' variant="outline-success" onClick={() => { window.location.href = 'http://localhost:3000/class' }} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </section>
        <div className='container' >
          <section className=' w-100 row gap-6'>
            <div className='d-flex w-100 gap-5'>
              <div>
              <a href='/s1'>
            {completeYears.length > 0 && (
                <div className='bg-white d-inline-block rounded '>
                  <h3>Count of students by CompleteYears</h3>
                  <BarChart
                    data={completeYears}
                    xAxis={[{ id: 'barCategories', data: completeYears.map(item => item._id), scaleType: 'band' }]}
                    series={[{ data: completeYears.map(item => item.count) }]}
                    height={300}
                    width={600}
                  />
                </div>
              )}
               <p className='text-center '>fig.1:Count of students by House</p> 
               </a>
              </div>

              <div>
                <a href='/s2'>
            {isolated.length > 0 && (
                <div className='bg-white d-inline-block rounded '>
                  <h3>Count of students by Isolated</h3>
                  <PieChart
                    series={[
                      {
                        innerRadius: 80,
                        outerRadius: 120,
                        data: isolated.map(item => ({ label: String(item._id), value: item.count })),
                      },
                    ]}
                    width={500}
                    height={300}
                  />
                </div>
              )}
               <p className='text-center '>fig.2:Count of students by Isolated</p> 
               </a>
              </div>
            </div>

            <div className='d-flex w-100 gap-5'>
              <div>
              <a href='/s3'>
            {opinion.length > 0 && (
                  <div className='bg-white d-inline-block rounded'>
                    <h3>Count of students by opinion</h3>
                    <LineChart
                      xAxis={[{ data: opinion.filter(item => item._id !== 'NA').map(item => item._id) }]}
                      series={[
                        {
                          data: opinion.filter(item => item._id !== 'NA').map(item => item.count),
                        },
                        {
                          data:comfortable.map(i=>i.count),
                          area: true,
                        },
                      ]}
                      height={300}
                      width={500}
                      margin={{ top: 10, bottom: 20 }}
                      skipAnimation
                    />
                  </div>
                )}
               
                <p className='text-center '>fig.3:Count of students by opinion</p> 
                </a>
              </div>

              <div>
                <a href='/s4'>
                {school_activity_club.length > 0 && (
                  <div className='bg-white d-inline-block rounded'>
                    <h3>Count of students by School Activity Club</h3>
                    <BarChart
                      data={completeYears}
                      xAxis={[{ id: 'barCategories', data: school_activity_club.map(item => item._id), scaleType: 'band' }]}
                      series={[{ data: school_activity_club.map(item => item.count) }]}
                      height={300}
                      width={600}
                    />
                  </div>
                )}
                <p className='text-center '>fig.4:Count of students by School Activity Club</p> 
                </a>
              </div>
            </div>

            <div className='d-flex w-100 gap-5'>
              <div>
              <a href='/s5'>
                {COVID.length > 0 && (
                  <div className='bg-white d-inline-block rounded'>
                    <h3>Count of students by COVID</h3>
                    <LineChart
                      xAxis={[{ data: COVID.filter(item => item._id !== 'NA').map(item => item._id), }]}
                      series={[
                        {
                          data: COVID.filter(item => item._id !== 'NA').map(item => item.count),
                          area: true,
                        },
                      ]}
                      width={600}
                      height={300}
                    />
                  </div>
                )}
                <p className='text-center '>fig.5:Count of students by COVID</p> 
                </a>
              </div>

              <div>
              <a href='/s6'>
                {bullying.length > 0 && (
                  <div className='bg-white d-inline-block rounded'>
                    <h3>Count of students by Bullying</h3>
                    <LineChart
                      xAxis={[{ data: bullying.filter(item => item._id !== 'NA').map(item => item._id) }]}
                      series={[
                        {
                          data: bullying.filter(item => item._id !== 'NA').map(item => item.count),
                        },
                        {
                          data:comfortable.map(i=>i.count),
                          area: true,
                        },
                      ]}
                      height={300}
                      width={500}
                      margin={{ top: 10, bottom: 20 }}
                      skipAnimation
                    />
                  </div>
                )}
                <p className='text-center '>fig.6:Count of students by Bullying</p> 
                </a>
              </div>
            </div>

          </section>
        </div>
        <section>
          <footer>
            <div class="footer">
              <div class="container">
                <div class="copyright">
                  <div class="line"></div>
                  <div class="d-flex justify-content-between">
                    <p>Copyright © 2024 Data Analysis | Powered by Student</p>
                    <div>
                      <span><FaFacebook /></span>
                      <span><FaInstagram /></span>
                      <span><FaTwitter /></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </footer>
        </section>
      </div>
    </div>
  );
}

export default Schoollevel;
