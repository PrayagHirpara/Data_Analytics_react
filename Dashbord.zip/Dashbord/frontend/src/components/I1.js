import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Container, Form, Nav, Navbar, Card } from 'react-bootstrap'
import { RiSchoolFill } from "react-icons/ri";
import { IoMdTime } from "react-icons/io";
import { IoIosSchool } from "react-icons/io";
import axios from 'axios';
import { useEffect, useState } from 'react';
import { BarChart, PieChart, pieArcLabelClasses, LineChart, SparkLineChart, ScatterChart } from '@mui/x-charts';

function I1() {
  const [future, setFuture] = useState([]);
  const [friends, setFriends] = useState([]);
  const [growthMindset, setGrowthMindset] = useState([]);
  const [intelligence1, setIntelligence1] = useState([]);
  const [manbox5_overall, setManbox5_overall] = useState([]);
  const [intelligence2, setIntelligence2] = useState([]);
  const [house, setHouse] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/admins/dashboard')
      .then(function (response) {
        // setFuture(response.data.future);
        setFriends(response.data.friends);
        setGrowthMindset(response.data.growthMindset);
        setIntelligence1(response.data.intelligence1);
        setManbox5_overall(response.data.manbox5_overall);
        setIntelligence2(response.data.intelligence2);
        setHouse(response.data.house);
        console.log(response.data.COVID.filter(item => item._id !== 'NA').map(item => item._id));
        console.log()
      })
      .catch(function (error) {
        console.log(error);
      })
  }, []);

  return (
    <div>
      
      <div className='body1'>

        <div className='container' >
          <section className=' w-100  gap-5'>
           <div className='d-flex w-100 gap-5'>
            <div>
            
            {growthMindset.length > 0 && (
                  <div className='bg-white d-inline-block rounded m-auto1'>
                    <h3>Count of students by growthMindset</h3>
                    <LineChart
                      xAxis={[{ data: growthMindset.filter(item => item._id !== 'NA').map(item => item._id) }]}
                      series={[
                        {
                          data: growthMindset.filter(item => item._id !== 'NA').map(item => item.count),
                        },
                        {
                          data:house.map(i=>i.count),
                          area: true,
                        },
                      ]}
                      height={450}
                      width={800}
                      margin={{ top: 10, bottom: 20 }}
                      skipAnimation
                    />
                  </div>
                )}
             
              
            </div>

           
          </div>
             
          </section>
        </div>
      </div>
    </div>
  );
}

export default I1;