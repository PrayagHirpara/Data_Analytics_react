import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Container, Form, Nav, Navbar, Card } from 'react-bootstrap'
import { RiSchoolFill } from "react-icons/ri";
import { IoMdTime } from "react-icons/io";
import { IoIosSchool } from "react-icons/io";
import axios from 'axios';
import { useEffect, useState } from 'react';
import { BarChart, PieChart, pieArcLabelClasses, LineChart, SparkLineChart } from '@mui/x-charts';

function I3() {
  const [future, setFuture] = useState([]);
  const [friends, setFriends] = useState([]);
  const [growthMindset, setGrowthMindset] = useState([]);
  const [intelligence1, setIntelligence1] = useState([]);
  const [manbox5_overall, setManbox5_overall] = useState([]);
  const [intelligence2, setIntelligence2] = useState([]);
  const [house, setHouse] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/admins/dashboard')
      .then(function (response) {
        // setFuture(response.data.future);
        setFriends(response.data.friends);
        setGrowthMindset(response.data.growthMindset);
        setIntelligence1(response.data.intelligence1);
        setManbox5_overall(response.data.manbox5_overall);
        setIntelligence2(response.data.intelligence2);
        setHouse(response.data.house);
        console.log(response.data.COVID.filter(item => item._id !== 'NA').map(item => item._id));
        console.log()
      })
      .catch(function (error) {
        console.log(error);
      })
  }, []);

  return (
    <div>
      
      <div className='body1'>

        <div className='container' >
          <section className=' w-100  gap-5'>
          
          
            <div>
              {manbox5_overall.length > 0 && (
                  <div className='bg-white d-inline-block rounded m-auto1'>
                    <h3>Count of students by Manbox5 overall</h3>
                    <LineChart
                      xAxis={[{ data: manbox5_overall.filter(item => item._id !== 'NA').map(item => item._id), }]}
                      series={[
                        {
                          data: manbox5_overall.filter(item => item._id !== 'NA').map(item => item.count),
                          area: true,
                        },
                      ]}
                      width={800}
                      height={450}
                    />
                  </div>
                )}
                
            </div>  
          </section>
        </div>
      </div>
    </div>
  );
}

export default I3;