import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Container, Form, Nav, Navbar, Card } from 'react-bootstrap'
import axios from 'axios';
import { useEffect, useState } from 'react';
import { FaFacebook, FaInstagram, FaTwitter } from "react-icons/fa";
import { BarChart, PieChart, LineChart } from '@mui/x-charts';
import Logout from './Logout';
import ForceGraph2D from 'react-force-graph-2d';
function Individuallevel() {
  const [friends, setFriends] = useState([]);
  const [attendance, setattendance] = useState([]);
  const [Perc_Effort, setPerc_Effort] = useState([]);
  const [manbox5_overall, setManbox5_overall] = useState([]);
  const [Perc_Academic, setPerc_Academic] = useState([]);
  const [house, setHouse] = useState([]);
  const [friendList, setFriendList] = useState([]);
  const [forceGraphData, setForceGraphData] = useState({});

  useEffect(() => {
    axios.get('http://localhost:5000/admins/dashboard')
      .then(function (response) {
        setFriends(response.data.friends);
        setattendance(response.data.attendance);
        setPerc_Effort(response.data.Perc_Effort);
        setManbox5_overall(response.data.manbox5_overall);
        setPerc_Academic(response.data.Perc_Academic);
        setHouse(response.data.house);
        setFriendList(response.data.friends_list);
        console.log(response.data.COVID.filter(item => item._id !== 'NA').map(item => item._id));
        console.log(friendList)

      })
      .catch(function (error) {
        console.log(error);
      })
  }, []);

  async function initForceGraphData() {
    let nodeList = friendList.flatMap((row) => [row.Source, row.Target])
    let unique_node_list = [...new Set(nodeList)]

    const nodes = unique_node_list.map((node) => {
      return {
        id: node,
        name: node,
        val: 5
      }
    })

    const links = friendList.map((row) => {
      return {
        "source": row.Source,
        "target": row.Target
      }
    })
    setForceGraphData({
      nodes: nodes,
      links: links
    })

    console.log(forceGraphData)
  }

  useEffect(() => {
    initForceGraphData()

  }, [friendList])

  return (
    <div>
      <div className='header-bg-green'>
        <header className='header1 container'>
          <Navbar expand="lg" className="">
            <Container fluid>
              <Navbar.Brand href="/" className='text-white'>ANALYTICS</Navbar.Brand>
              <Navbar.Toggle aria-controls="navbarScroll" />
              <Navbar.Collapse id="navbarScroll">
                <Nav className="me-auto my-2 my-lg-0" style={{ maxHeight: '100px' }} navbarScroll></Nav>
                <Form className="d-flex">
                  <Button className='m-2 text-white border-white' variant="outline-success"><Logout /></Button>
                </Form>
              </Navbar.Collapse>
            </Container>
          </Navbar>
        </header>
      </div>
      <div className='body'>
        <section>
          <div className="container1">
            <section className="carousel slide" id="carousel" data-bs-ride="carousel">
              <div className="carousel-inner">
                <div className="carousel-item active" data-bs-interval="">
                  <div className="container h-75">
                    <div className="d-flex justify-content-start align-items-center h-100">
                      <div className="text-start text-white">
                        <h2 className="fw-bold  display-2">Individual Level</h2>
                        <h5 className="p-2 my-3 fs-7 d-flex flex-wrap opacity-75">"Explore student-specific data revealing academic and social patterns that<br></br> impact individual growth and success. Our comprehensive approach goes<br></br> beyond traditional education by delving into nuanced insights, enabling<br></br> tailored support and fostering a vibrant community where every student<br></br> thrives. Join us in shaping a future where each individual's potential is<br></br> recognized and nurtured."</h5><br />
                        <div className='d-flex '>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>

        </section>
        <div className='container' >
          <div className="inputBox">
            
          </div>
          <section className=' w-100  gap-5'>
            <div className='d-flex w-100 gap-5'>
              <div>
                <a href='/i1'>
                  {attendance.length > 0 && (
                    <div className='bg-white d-inline-block rounded '>
                      <h3>Count of students by attendance</h3>
                      <LineChart
                        xAxis={[{ data: attendance.filter(item => item._id !== 'NA').map(item => item._id) }]}
                        series={[
                          {
                            data: attendance.filter(item => item._id !== 'NA').map(item => item.count),
                          },
                          {
                            data: house.map(i => i.count),
                            area: true,
                          },
                        ]}
                        height={300}
                        width={600}
                        margin={{ top: 10, bottom: 20 }}
                        skipAnimation
                      />
                    </div>
                  )}

                  <p className='text-center'>fig.1:Count of students by attendance</p>
                </a>
              </div>

              <div>
                <a href='/i2'>
                  {attendance.length > 0 && (
                    <div className='bg-white d-inline-block rounded '>
                      <h3>Node Graph of Student Friends</h3>
                      <ForceGraph2D
                        height={300}
                        width={600}
                        graphData={forceGraphData}
                        nodeCanvasObject={(node, ctx, globalScale) => {
                          const label = node.id;
                          const fontSize = 12 / globalScale;
                          ctx.font = `${fontSize}px Sans-Serif`;
                          ctx.fillText(label, node.x, node.y);
                        }}
                        enablePointerInteraction={false}
                      />
                    </div>
                  )}
                </a>
                <p className='text-center'>fig.2:Node Graph of Student Friends</p>

              </div>


            </div>

            <div className='d-flex w-100 gap-5'>
              <div>
                <a href='/i3'>
                  {manbox5_overall.length > 0 && (
                    <div className='bg-white d-inline-block rounded'>
                      <h3>Count of students by Manbox5 overall</h3>
                      <LineChart
                        xAxis={[{ data: manbox5_overall.filter(item => item._id !== 'NA').map(item => item._id), }]}
                        series={[
                          {
                            data: manbox5_overall.filter(item => item._id !== 'NA').map(item => item.count),
                            area: true,
                          },
                        ]}
                        width={600}
                        height={300}
                      />
                    </div>
                  )}
                  <p className='text-center'>fig.3:Count of students by Manbox5 overall</p>
                </a>
              </div>

              <div>
                <a href='/i4'>
                  {Perc_Academic.length > 0 && (
                    <div className='bg-white d-inline-block rounded '>
                      <h3>Count of students by Perc Academic</h3>
                      <LineChart
                        xAxis={[{ data: Perc_Academic.filter(item => item._id !== 'NA').map(item => item._id) }]}
                        series={[
                          {
                            data: Perc_Academic.filter(item => item._id !== 'NA').map(item => item.count),
                          },
                          {
                            data: house.map(i => i.count),
                            area: true,
                          },
                        ]}
                        height={300}
                        width={600}
                        margin={{ top: 10, bottom: 20 }}
                        skipAnimation
                      />
                    </div>
                  )}
                  <p className='text-center'>fig.4:Count of students by Perc Academic</p>
                </a>
              </div>
            </div>

            <div className='d-flex w-100 gap-5'>
              <div>
                <a href='/i5'>
                  {friends.length > 0 && (
                    <div className='bg-white d-inline-block rounded'>
                      <h3>Count of students by Friends</h3>
                      <PieChart
                        series={[
                          {
                            innerRadius: 80,
                            outerRadius: 120,
                            data: friends.map(item => ({ label: String(item._id), value: item.count })),
                          },
                        ]}
                        width={600}
                        height={300}
                      />
                    </div>
                  )}
                  <p className='text-center'>fig.5:Count of students by friends</p>
                </a>
              </div>

              <div>
                <a href='/i6'>
                  {Perc_Effort.length > 0 && (
                    <div className='bg-white d-inline-block rounded'>
                      <h3>Count of students by Perc Effort</h3>
                      <BarChart
                        data={Perc_Effort}
                        xAxis={[{ id: 'barCategories', data: Perc_Effort.map(item => item._id), scaleType: 'band' }]}
                        series={[{ data: Perc_Effort.map(item => item.count) }]}
                        height={300}
                        width={600}
                      />
                    </div>
                  )}
                  <p className='text-center'>fig.6:Count of students by Perc Effort</p>
                </a>
              </div>
            </div>

          </section>
        </div>
        <section>
          <footer>
            <div class="footer">
              <div class="container">
                <div class="copyright">
                  <div class="line"></div>
                  <div class="d-flex justify-content-between">
                    <p>Copyright © 2024 Data Analysis | Powered by Student</p>
                    <div>
                      <span><FaFacebook /></span>
                      <span><FaInstagram /></span>
                      <span><FaTwitter /></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </footer>
        </section>
      </div>
    </div>
  );
}

export default Individuallevel;