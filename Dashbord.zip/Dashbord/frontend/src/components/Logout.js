export default function Logout() {
    return (
        <>
            <button className="btn" onClick={() => {
                if (window.confirm("are you sure")) {
                    localStorage.clear()
                    window.location.href = "/"
                }
            }}><a href="/" className=" text-decoration-none text-white">Logout</a></button>
        </>
    )
}