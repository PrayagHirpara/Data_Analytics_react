import '../App.css';
import { useState } from "react";
import Header from "./Header";
import { FaSignInAlt } from "react-icons/fa";

function Sign_in() {
  var [email, setemail] = useState()
  var [password, setpassword] = useState()
  var [role, setrole] = useState()

  function send_data() {
    Header.post('/admins/', {
      email: email,
      password: password,
      role: role
    })
      .then(function (response) {
        if (response.data.status == "success") {
          if (response.data.role == "admin") {
            localStorage.setItem('authorization', response.data.token);
            localStorage.setItem('role', "admin");
            window.location.href = "/school";
          } else if (response.data.role == "student") {
            localStorage.setItem('authorization', response.data.token);
            localStorage.setItem('role', "student");
            window.location.href = "/individual";
          }
          else if (response.data.role == "teacher") {
            localStorage.setItem('authorization', response.data.token);
            localStorage.setItem('role', "teacher");
            window.location.href = "/class";
          } else {
            alert("Role not recognized");
          }
        } else {
          alert("Check your email and password");
        }
      })

      .catch(function (error) {
        console.log(error);
      });
  }
  return (
    <div className='body2'>
      <title>Login Form</title>

      <div className="form ">
        <h2>Login</h2>
        <div className="input">
          <div className="inputBox">
            <label htmlFor>Email</label>
            <input type="text" onChange={(e) => { setemail(e.target.value) }} />
          </div>
          <div className="inputBox">
            <label htmlFor>Password</label>
            <input type="password" onChange={(e) => { setpassword(e.target.value) }} />
          </div>
          <div className="inputBox">
            <label htmlFor>Role</label>
            <select className="inputBox text-white w-1/2 p-1 rounded-md mx-auto h-8 " onChange={(e) => { setrole(e.target.value) }} >
              <option selected disabled >Select Role</option>
              <option value="admin" className='text-black'>Admin</option>
              <option value="student" className='text-black'>Student</option>
              <option value="teacher" className='text-black'>Teacher</option>
            </select>
          </div>
          <div className="d-flex">
            <input type="checkbox" name defaultValue="Sign Up" /><p className='text-white pt-3 ps-2'>Remember Me</p>
          </div>
          <div className="inputBox">
            <input type="submit" name defaultValue="Sign In " className='mb-3' onClick={() => { send_data() }} />
          </div>
        </div>

      </div>
    </div>
  );
}
export default Sign_in;