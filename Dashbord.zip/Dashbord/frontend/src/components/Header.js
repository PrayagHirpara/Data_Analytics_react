import axios from "axios";

const Header = axios.create({
    baseURL: "http://localhost:5000",
    headers: {
        "authorization": localStorage.getItem("authorization")
    }
})

export default Header