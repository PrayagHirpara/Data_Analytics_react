import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import { useEffect, useState } from 'react';
import ForceGraph2D from 'react-force-graph-2d';

function I2() {
  const [friendList, setFriendList] = useState([]);
  const [forceGraphData, setForceGraphData] = useState({});

  useEffect(() => {
    axios.get('http://localhost:5000/admins/dashboard')
      .then(function (response) {
        setFriendList(response.data.friends_list);
        console.log(friendList)

      })
      .catch(function (error) {
        console.log(error);
      })
  }, []);

  async function initForceGraphData() {
    let nodeList = friendList.flatMap((row) => [row.Source, row.Target])
    let unique_node_list = [...new Set(nodeList)]

    const nodes = unique_node_list.map((node) => {
      return {
        id: node,
        name: node,
        val: 5
      }
    })

    const links = friendList.map((row) => {
      return {
        "source": row.Source,
        "target": row.Target
      }
    })
    setForceGraphData({
      nodes: nodes,
      links: links
    })

    console.log(forceGraphData)
  }

  useEffect(() => {
    initForceGraphData()

  }, [friendList])

  return (
    <div>

      <div className='body1'>

        <div className='container' >
          <section className=' w-100  gap-5'>
            <div className='d-flex w-100 gap-5'>
              <div>

                {forceGraphData.nodes?.length > 0 && (
                  <div className='bg-white d-inline-block rounded '>
                    <h3>Node Graph of Student Friends</h3>
                    <ForceGraph2D
                      height={300}
                      width={600}
                      graphData={forceGraphData}
                      nodeCanvasObject={(node, ctx, globalScale) => {
                        const label = node.id;
                        const fontSize = 12 / globalScale;
                        ctx.font = `${fontSize}px Sans-Serif`;
                        ctx.fillText(label, node.x, node.y);
                      }}
                      enablePointerInteraction={false}
                    />
                  </div>
                )}
                <p className='text-center'>fig.2:Node Graph of Student Friends</p>
              </div>


            </div>

          </section>
        </div>
      </div>
    </div>
  );
}

export default I2;