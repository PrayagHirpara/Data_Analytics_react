
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Routes, Route, Navigate } from "react-router-dom";
import Schoollevel from './components/Schoollevel';
import Classlevel from './components/Classlevel';
import Individuallevel from './components/Individuallevel';
import Sign_in from './components/Sign_in';
import Logout from './components/Logout';
import I1 from './components/I1';
import I2 from './components/I2';
import I3 from './components/I3';
import I4 from './components/I4';
import I5 from './components/I5';
import I6 from './components/I6';
import S1 from './components/S1';
import S2 from './components/S2';
import S3 from './components/S3';
import S4 from './components/S4';
import S5 from './components/S5';
import S6 from './components/S6';
import C1 from './components/C1';
import C5 from './components/C5';
import C4 from './components/C4';
import C3 from './components/C3';
import C2 from './components/C2';




function App() {

  return (
    <div>
      <Routes>
        <Route path="/school" element={<Schoollevel />} />
        <Route path="/class" element={<Classlevel />} />
        <Route path="/individual" element={<Individuallevel />} />
        <Route path="/" element={<Sign_in />} />
        <Route path="/logout" element={<Logout />} />
        <Route path="/i1" element={<I1 />} />
        <Route path="/i2" element={<I2 />} />
        <Route path="/i3" element={<I3 />} />
        <Route path="/i4" element={<I4 />} />
        <Route path="/i5" element={<I5 />} />
        <Route path="/i6" element={<I6 />} />
        <Route path="/s1" element={<S1 />} />
        <Route path="/s2" element={<S2 />} />
        <Route path="/s3" element={<S3 />} />
        <Route path="/s4" element={<S4 />} />
        <Route path="/s5" element={<S5 />} />
        <Route path="/s6" element={<S6 />} />
        <Route path="/c1" element={<C1 />} />
        <Route path="/c2" element={<C2 />} />
        <Route path="/c3" element={<C3 />} />
        <Route path="/c4" element={<C4 />} />
        <Route path="/c5" element={<C5 />} />
      </Routes>
    </div>
  );
}

export default App;
