var jwt = require('jsonwebtoken');

exports.admin = (req,res,next)=>{
    jwt.verify(req.get('authorization'),'admin',next())

}

exports.student = (req,res,next)=>{
    jwt.verify(req.get('authorization'),'student',next())

}