var express = require('express');
var router = express.Router();
var student =require('../controller/adminscontroller');
var auth =require('../middleware/auth');


/* GET home page. */
router.post('/add',student.add);
router.post('/',student.login);
router.get('/deletes/:id',student.deletes);
router.post('/update/:id',student.update);
router.get('/logout',student.logout);
router.get('/dashboard',student.dashboard);
router.post('/register',student.register);
router.post('/logout',student.logout);

module.exports = router;
