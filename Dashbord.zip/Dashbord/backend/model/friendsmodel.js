const mongoose = require('mongoose');

const friends = new mongoose.Schema({
    Source: { type: Number },
    Target: { type: Number }
})

module.exports = mongoose.model('friend', friends)