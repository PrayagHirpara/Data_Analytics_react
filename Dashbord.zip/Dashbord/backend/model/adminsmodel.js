const mongoose = require('mongoose');

const student = new mongoose.Schema({
    Email: { type: String, required: true, unique: true },
    Password: { type: String },
    Role: { type: String }
})

module.exports = mongoose.model('admin', student)