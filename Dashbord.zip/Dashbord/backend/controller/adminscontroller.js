var studentdb = require('../model/adminsmodel');
const storage = require('node-persist');
const DynamicModel = require('../model/studentmodel')
const FriendsModel = require('../model/friendsmodel')
var jwt = require('jsonwebtoken');



exports.login = async (req, res) => {

    var data = await studentdb.find({ Email: req.body.email, Role: req.body.role });
    if (data.length == 1) {
        if (req.body.password === data[0].Password) {
            var token = jwt.sign({ id: data[0].id }, 'admin');
            console.log(data[0].role)
            if (req.body.role === "admin" && data[0].Role === "admin") {
                console.log(req.body)
                res.status(200).json({
                    status: "success",
                    token,
                    role: "admin"
                })
            }
            else if (req.body.role === "student" && data[0].Role === "student") {
                res.status(200).json({
                    status: "success",
                    token,
                    role: "student"
                })
            }
            else if (req.body.role === "teacher" && data[0].Role === "teacher") {
                res.status(200).json({
                    status: "success",
                    token,
                    role: "teacher"
                })
            }
            else {
                res.status(200).json({
                    status: "check your email and password"
                })
            }

        }
        else {
            res.status(200).json({
                status: "check your email and password"
            })
        }
    }
    else {
        res.status(200).json({
            status: "check your email and password"
        })
    }
}

exports.deletes = async (req, res) => {
    var id = req.params.id;
    var data = await studentdb.findByIdAndDelete(id);

    res.status(200).json({
        status: "delete data",
        data
    })
}

exports.update = async (req, res) => {
    var id = req.params.id;
    var data = await studentdb.findByIdAndUpdate(id, req.body);
    res.status(200).json({
        status: "update data",
        data
    })
}


exports.logout = async (req, res) => {
    await storage.init( /* options ... */);
    var id = await storage.clear();

    res.status(200).json({
        status: "logout"
    })
}


exports.register = async (req, res) => {
    if (req.body.role === "admin") {
        const data = await studentdb.create(req.body);
        res.status(200).json({
            status: "Admin Register",
            data
        });
    }
    else if (req.body.role === "student") {
        const data = await studentdb.create(req.body);
        res.status(200).json({
            status: "Student Register",
            data
        });
    }
    else {
        const data = await studentdb.create(req.body);
        res.status(200).json({
            status: "Teacher Register",
            data
        });
    }
}


exports.add = async (req, res) => {

    try {
        var data = await studentdb.create(req.body)
        res.status(200).json({
            status: "successfull",
            data
        })


    } catch (error) {

        res.status(200).json({
            status: "email not valid",
            data
        })

    }

}

exports.dashboard = async (req, res) => {
    try {
        console.log("data")
        const friends = await DynamicModel.aggregate([{ $group: { _id: "$Friends", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const intelligence1 = await DynamicModel.aggregate([{ $group: { _id: "$Intelligence1", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const opinion = await DynamicModel.aggregate([{ $group: { _id: "$opinion", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const school_activity_club = await DynamicModel.aggregate([{ $group: { _id: "$School Activity Club", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const COVID = await DynamicModel.aggregate([{ $group: { _id: "$COVID", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const bullying = await DynamicModel.aggregate([{ $group: { _id: "$bullying", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const comfortable = await DynamicModel.aggregate([{ $group: { _id: "$comfortable", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const attendance = await DynamicModel.aggregate([{ $group: { _id: "$Attendance", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const intelligence2 = await DynamicModel.aggregate([{ $group: { _id: "$Intelligence2", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const perc_academic = await DynamicModel.aggregate([{ $group: { _id: "$Perc_Academic", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const feedback = await DynamicModel.aggregate([{ $group: { _id: "$Feedback", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const influential = await DynamicModel.aggregate([{ $group: { _id: "$Influential", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const menBetterSTEM = await DynamicModel.aggregate([{ $group: { _id: "$MenBetterSTEM", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const school_support_engage6 = await DynamicModel.aggregate([{ $group: { _id: "$School_support_engage6", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const completeYears = await DynamicModel.aggregate([{ $group: { _id: "$CompleteYears", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const future = await DynamicModel.aggregate([{ $group: { _id: "$Future", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const growthMindset = await DynamicModel.aggregate([{ $group: { _id: "$GrowthMindset", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const manbox5_overall = await DynamicModel.aggregate([{ $group: { _id: "$Manbox5_overall", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const moreTime = await DynamicModel.aggregate([{ $group: { _id: "$MoreTime", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const house = await DynamicModel.aggregate([{ $group: { _id: "$House", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const isolated = await DynamicModel.aggregate([{ $group: { _id: "$isolated", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const Perc_Academic = await DynamicModel.aggregate([{ $group: { _id: "$Perc_Academic", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const Perc_Effort = await DynamicModel.aggregate([{ $group: { _id: "$Perc_Effort", count: { $sum: 1 } } }, { $sort: { _id: 1 } }])
        const friends_list = await FriendsModel.find({})
        res.status(200).json({
            status: "success",
            friends,
            intelligence1,
            opinion,
            school_activity_club,
            COVID,
            bullying,
            comfortable,
            attendance,
            intelligence2,
            perc_academic,
            feedback,
            influential,
            menBetterSTEM,
            school_support_engage6,
            completeYears,
            future,
            growthMindset,
            manbox5_overall,
            moreTime,
            house,
            isolated,
            Perc_Academic,
            Perc_Effort,
            friends_list
        })
    }
    catch (err) {
        console.log("err", err)
    }
}